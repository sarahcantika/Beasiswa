<!DOCTYPE html>
<html>
<head>
	<title>	</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<section class="bg1" style="text-align: center; padding-bottom: 2em">
    <div class="tulisan">
        <table>
            <tr>
                <td><h1  style="font-size: 25px;" >Aplikasi Cinta cita ini merupakan platfrom penyedia informasi mengenai beasiswa yang sedang berlangsung saat ini. Pengguna dapat mendapatkan berbagai macam manfaat didalamnya termasuk pendaftaran beasiswa tanpa harus bersusah payah. Berbagai macam beasiswa khususnya untuk mahasiswa terdapat aplikasi ini. Terdapat juga detail dari beasiswa sehingga menambah informasi yang akan didapatkan. Tunggu apa lagi yuk gabung sekarang.</h1></td>
            </tr>
            <tr><th></th></tr>
            <tr><th></th></tr>
            <tr>
                <td><button style="font-family: Century" ><a href="Utama.php">Kembali</a></button></td>
            </tr>
        </table>
    
    </div>
    <br>
   
	<div class="bg3"></div>
    </section>
</body>
</html>