  <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title></title>
    </head>
    <body>
     
    <div class="container">
    <div class="row">-->
        <?php
for ($x = 0; $x <= 2; $x++) { 
  ?>
  <div class="col d-flex justify-content-center">
      <table>

    <tr>
      <td colspan="2">
        <img width="100" src="rois-1.png">
      </td>
    </tr>
    <tr>
    <td>
      <a class="btn btn-warning" href="tambah_data.php"></a>
    </td>
    <td>
      <a class="btn btn-warning" href="detail.php"></a>
    </td>
    </tr>
  </table>
  </div>

  <?php
}
?>
  </div>
  </div>
  </body>
    </html> 
