<!DOCTYPE html>
<html>
<head>
	<title>	</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<section class="bg" style="text-align: center; padding-bottom: 2em">
	<div class="bg2">
        <h1  style="font-size: 70px;" >Selamat Datang Para Juara</h1>
        <br>

        <div class="button">
        <button style="font-family: Century" ><a href="detail_app.php">Detail Aplikasi</a></button>
        <button style="font-family: Century"><a href="beranda.php">Beranda</a></button>
        </div>
        </div>
    </section>
</body>
</html>