

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="style.css"> 
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@1,500&display=swap" rel="stylesheet">

	<title>beasiswa</title>
</head>
<body>
  <div class="container">
    <div class="row">
        <?php
for ($x = 0; $x <= 2; $x++) { 
  ?>
  <div class="col d-flex justify-content-center">
      <table>

    <tr>
      <td colspan="2">
        <img width="100" src="rois-1.png">
      </td>
    </tr>
    <tr>
    <td>
      <a class="btn btn-warning" href="tambah_data.php"></a>
    </td>
    <td>
      <a class="btn btn-warning" href="detail.php"></a>
    </td>
    </tr>
  </table>
  </div>

  <?php
}
?>
    </div>
  </div>

</body>
</html>